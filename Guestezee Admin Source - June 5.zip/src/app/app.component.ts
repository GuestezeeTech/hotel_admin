import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, NavigationEnd, RouterOutlet } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { MenuBarComponent } from './shared/menu-bar/menu-bar.component';
import { HeaderComponent } from './shared/header/header.component';
import { LocalStorageService } from './auth-services/local-storage.service';
import { PushService } from './services/push.service';
import { NotificationService } from './notification/notification.service';
import { ProfileService } from './profile/profile.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, MenuBarComponent, HeaderComponent, LoginComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss',
})
export class AppComponent implements OnInit, OnDestroy {
  title = 'GUESTEZEE_ADMIN';

  // Checks whether the given input element is an email/mail field
  private isEmailInputField(target: HTMLInputElement): boolean {
    const type = (target.getAttribute('type') || 'text').toLowerCase();
    const name = (target.getAttribute('name') || '').toLowerCase();
    const id = (target.id || '').toLowerCase();
    const fcn = (target.getAttribute('formcontrolname') || '').toLowerCase();
    const ph = (target.getAttribute('placeholder') || '').toLowerCase();
    return (
      type === 'email' ||
      name === 'email' || name === 'mail' || name.includes('email') ||
      (name.includes('mail') && !name.includes('address')) ||
      id === 'email' || id === 'mail' || id.includes('email') ||
      (id.includes('mail') && !id.includes('address')) ||
      fcn === 'email' || fcn === 'mail' || fcn.includes('email') ||
      (fcn.includes('mail') && !fcn.includes('address')) ||
      ph.includes('email') ||
      (ph.includes('mail') && !ph.includes('address'))
    );
  }

  // Flag to suppress handleGlobalInput for the synthetic event we dispatch ourselves
  private _suppressInput = false;

  // Keydown handler: intercepts uppercase characters BEFORE browser inserts them.
  // This avoids Angular's reactive form writeValue() resetting the cursor to end.
  handleGlobalKeydown = (event: KeyboardEvent) => {
    const target = event.target as HTMLInputElement;
    if (!target) return;
    const tag = target.tagName;
    const type = (target.getAttribute('type') || 'text').toLowerCase();
    const isTextEntry = tag === 'TEXTAREA' || (tag === 'INPUT' && ['text', 'email', 'search', 'url', 'tel'].includes(type));
    if (!isTextEntry) return;
    if (!this.isEmailInputField(target)) return;

    // Only intercept single uppercase letters (A-Z), skip shortcuts like Ctrl+C
    if (
      event.key.length === 1 &&
      event.key >= 'A' && event.key <= 'Z' &&
      !event.ctrlKey && !event.metaKey && !event.altKey
    ) {
      event.preventDefault();
      const start = target.selectionStart ?? target.value.length;
      const end = target.selectionEnd ?? target.value.length;
      const cursorAfter = start + 1; // where cursor should land after inserting 1 char

      // Manually insert the lowercase character at the current cursor position
      const lower = event.key.toLowerCase();
      target.value = target.value.slice(0, start) + lower + target.value.slice(end);

      // Notify Angular's reactive form / ngModel that the value changed.
      // Suppress our own handleGlobalInput from reacting to this synthetic event.
      // Angular's (input)="clearError('email')" may call markAsPristine() → CD → writeValue()
      // which resets cursor to end. So we restore AFTER via microtask.
      this._suppressInput = true;
      target.dispatchEvent(new Event('input', { bubbles: true }));
      this._suppressInput = false;

      // Restore cursor AFTER Angular's synchronous markAsPristine/writeValue pipeline
      Promise.resolve().then(() => {
        target.setSelectionRange(cursorAfter, cursorAfter);
      });
    }
  };

  // Input handler: handles paste / autofill / IME — no cursor issue in those cases
  handleGlobalInput = (event: Event) => {
    if (this._suppressInput) return; // ignore our own synthetic event
    const target = event.target as HTMLInputElement;
    if (!target) return;
    const tag = target.tagName;
    const type = (target.getAttribute('type') || 'text').toLowerCase();
    const isTextEntry = tag === 'TEXTAREA' || (tag === 'INPUT' && ['text', 'email', 'search', 'url', 'tel'].includes(type));
    if (!isTextEntry) return;
    if (!this.isEmailInputField(target)) return;
    if (target.value && target.value !== target.value.toLowerCase()) {
      target.value = target.value.toLowerCase();
    }
  };
  showSidebar = true;
  selectedMenuItem: string = '';
  showNotification = false;
  customerType: string | null = null;
  private audioUnlocked = false;
  notifications: any[] = [];

  private routesWithoutSidebar = ['/login', '/', '/view'];

  constructor(
    private router: Router,
    private localservice: LocalStorageService,
    private pushService: PushService,
    private notificationService: NotificationService
  ) {
    // --- Sidebar and menu tracking ---
    this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        //newly added for logged out issue
        const url = event.urlAfterRedirects || event.url || '';
        // Allow enrollment routes even when loggedOut flag is set (payment callbacks, cancellations)
        const path = (this.router?.url || window.location.pathname || '').toLowerCase().replace(/\/+$/, '');
        const isEnrollmentRoute = path.includes('hotel-registration') || path.includes('confirmation') || path.includes('cancellation') || path.includes('payment');
        // Newly added for browser back button
        // Global Guard: If logged out, prevent access to any page except login
        // if (this.localservice.get('loggedOut') === 'true' && event.url !== '/' && event.url !== '/login' && !event.url.startsWith('/login')) {
        if (this.localservice.get('loggedOut') === 'true' && !isEnrollmentRoute && url !== '/' && url !== '/login' && !url.startsWith('/login')) {
          this.router.navigate(['/login'], { replaceUrl: true });
          return;
        }

        this.showSidebar = this.routesWithoutSidebar.some(route => route === event.url);
        // console.log('Current URL:', event.url);
        //newly commented for header issue
        // if (event.url == '/hotel-list' || event.url == '/add-new-hotel') this.selectedMenuItem = "Hotels";
        // // Newly added for terms and conditions & privacy policy
        // else if (event.url == '/privacy-policy') this.selectedMenuItem = "Privacy Policy";
        // else if (event.url == '/terms-conditions') this.selectedMenuItem = "Terms & Conditions";
        // // Newly added for dynamic department and service
        // else if (event.url == '/department-list') this.selectedMenuItem = "Department";
        // else if (event.url == '/service-list') this.selectedMenuItem = "Service";
        // else if (event.url == '/service-tab-list') this.selectedMenuItem = "Service Tab";
        // // Ended
        // else if (event.url == '/role-list' || event.url == '/role') this.selectedMenuItem = "Roles";
        // else if (event.url == '/user-list' || event.url == '/user') this.selectedMenuItem = "Users";
        // else if (event.url == '/staff-list' || event.url == '/staff') this.selectedMenuItem = "Staff";
        // else if (event.url == '/bookings') this.selectedMenuItem = "Bookings";
        // else if (event.url == '/bookings-management') this.selectedMenuItem = "Bookings & Guest Management";
        // else if (event.url == '/late-checkout') this.selectedMenuItem = "Late Checkout";
        // else if (event.url == '/settings') this.selectedMenuItem = "Settings";
        //newly added for header issue
        // const url = event.urlAfterRedirects || event.url;
        // newly commented and added
        //  if (url.includes('/hotel-list') || url.includes('/add-new-hotel') || url.includes('/edit-new-hotel') || url.includes('/hotel-registration')) {
        if (url.includes('/hotel-list') || url.includes('/add-new-hotel') || url.includes('/edit-new-hotel') || url.includes('/hotel-registration') || url.includes('/cancellation') || url.includes('/confirmation')) {
          this.selectedMenuItem = "Hotels";
        } else if (url.includes('/privacy-policy')) {
          this.selectedMenuItem = "Privacy Policy";
        } else if (url.includes('/terms-conditions')) {
          this.selectedMenuItem = "Terms & Conditions";
        } else if (url.includes('/department-list')) {
          this.selectedMenuItem = "Department";
        } else if (url.includes('/service-tab-list')) {
          this.selectedMenuItem = "Service Tab";
        } else if (url.includes('/service-list') || url.includes('/service') || url.includes('/add-new-service') || url.includes('/edit-service') || url.includes('/view-service')) {
          this.selectedMenuItem = "Service";
        } else if (url.includes('/role-list') || url.includes('/role')) {
          this.selectedMenuItem = "Roles";
        } else if (url.includes('/user-list') || url.includes('/user')) {
          this.selectedMenuItem = "Users";
        } else if (url.includes('/staff-list') || url.includes('/staff')) {
          this.selectedMenuItem = "Staff";
        } else if (url.includes('/bookings-management')) {
          this.selectedMenuItem = "Bookings & Guest Management";
        } else if (url.includes('/bookings')) {
          this.selectedMenuItem = "Bookings";
        } else if (url.includes('/late-checkout')) {
          this.selectedMenuItem = "Late Checkout";
        } else if (url.includes('/settings')) {
          this.selectedMenuItem = "Settings";
        } else if (url.includes('/member-hierarchy') || url.includes('/create-new-hierarchy') || url.includes('/edit-hierarchy') || url.includes('/view-hierarchy')) {
          this.selectedMenuItem = "Hierarchy";
        } else if (url.includes('/features') || url.includes('/restaurants-list') || url.includes('/features-list') || url.includes('/feature-creation')) {
          this.selectedMenuItem = "Features";
        } else if (url.includes('/payment-details') || url.includes('/payment-subscription')) {
          this.selectedMenuItem = "Payment";
        } else if (url.includes('/outlet-list') || url.includes('/outlet-creation') || url.includes('/create-outlet') || url.includes('/product') || url.includes('/add-product')) {
          this.selectedMenuItem = "Outlets";
        } else if (url.includes('/dashboard')) {
          this.selectedMenuItem = "Dashboard";
        } else if (url.includes('/profile')) {
          this.selectedMenuItem = "Profile";
        } else if (url.includes('/task-management') || url.includes('/create-task')) {
          this.selectedMenuItem = "Task Management";
        } else if (url.includes('/timeline')) {
          this.selectedMenuItem = "Timeline";
        }
        if (event.url.startsWith('/view-hierarchy') || event.url.startsWith('/view-customer-hierarchy')) {
          this.showSidebar = true;
        }
      }
      // console.log('Selected menu item:', this.selectedMenuItem);
    });
  }

  ngOnInit(): void {
    document.addEventListener('keydown', this.handleGlobalKeydown, true);
    document.addEventListener('input', this.handleGlobalInput, true);
    // --- Restore user info ---
    this.customerType = this.localservice.get('CustomerType');
    // console.log('[App] Customer Type:', this.customerType);
    const queryParams = new URLSearchParams(window.location.search);
    const customerIdFromUrl = queryParams.get('customer_id');
    if (customerIdFromUrl) {
      localStorage.setItem('customer_id', customerIdFromUrl);
      this.localservice.set('UserId', customerIdFromUrl);
      // console.log('[App] Restored customer_id:', customerIdFromUrl);
    }

    // --- Unlock audio context ---
    const unlockAudio = () => {
      // console.log('[App] Attempting to unlock audio...');
      if (!this.audioUnlocked) {
        try {
          const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
          const buffer = audioCtx.createBuffer(1, 1, 22050);
          const source = audioCtx.createBufferSource();
          source.buffer = buffer;
          source.connect(audioCtx.destination);
          source.start(0);
          this.audioUnlocked = true;
          // console.log('[App] Audio unlocked for notifications');
          window.removeEventListener('click', unlockAudio);
          window.removeEventListener('keydown', unlockAudio);
          window.removeEventListener('mousemove', unlockAudio);
        } catch (err) {
          console.warn('[App] Failed to unlock audio:', err);
        }
      }
    };
    window.addEventListener('click', unlockAudio);
    window.addEventListener('keydown', unlockAudio);
    window.addEventListener('mousemove', unlockAudio);
    unlockAudio(); // attempt immediate unlock
    // --- Foreground Notifications ---
    this.pushService.onMessageListener().subscribe((payload: any) => {
      // console.log('[App] Foreground message received:', payload);

      if (this.audioUnlocked) {
        const audio = new Audio('assets/images/guestezee/alarm.mp3');
        audio.play().then(() => {
          // console.log('[App] Foreground sound played');
        }).catch(err => {
          console.warn('[App] Foreground sound blocked:', err);
        });
      }

      const structuredData = this.extractNotificationData(payload);
      this.notificationService.addNotification(structuredData);
    });


    // --- Background Notifications from SW ---
    navigator.serviceWorker.addEventListener('message', (event: any) => {
      if (event.data?.action === 'playSound') {
        // console.log('[App] Received playSound from SW');
        if (this.audioUnlocked) {
          const audio = new Audio('assets/images/guestezee/alarm.mp3');
          audio.play().then(() => {
            // console.log('[App] Background sound played');
          }).catch(err => {
            console.warn('[App] Background sound blocked:', err);
          });
        }
      }
      // if (event.data?.action === 'openTaskManagement') {
      //   window.location.href = '/task-management';
      // }
    });
    // --- Staff-specific panel handling ---
    if (this.customerType === 'Staff') {
      this.notificationService.showPanel$.subscribe(show => this.showNotification = show);
    }
  }

  ngOnDestroy(): void {
    document.removeEventListener('keydown', this.handleGlobalKeydown, true);
    document.removeEventListener('input', this.handleGlobalInput, true);
  }

  updateMenu(value: string) {
    this.selectedMenuItem = value;
  }

  toggleNotification() {
    this.showNotification = !this.showNotification;
    if (!this.showNotification) this.notificationService.closePanel();
  }

  // --- Extract Notification Data (Structured) ---
  private extractNotificationData(payload: any) {
    let parsedMessage: any = {};
    try {
      if (payload?.data?.message) {
        let rawMessage = payload.data.message;
        try {
          parsedMessage = JSON.parse(rawMessage);
          if (typeof parsedMessage === 'string') parsedMessage = JSON.parse(parsedMessage);
        } catch {
          console.warn('[App] Failed nested JSON parse:', rawMessage);
        }
      }
    } catch (err) {
      console.warn('[App] Failed to parse payload.data.message:', err);
    }
    const structured = {
      title: payload?.notification?.title || 'No Title',
      body: payload?.notification?.body || '',
      task_id: parsedMessage?.task_id || null,
      redirection_tab: parsedMessage?.redirection_tab || null,
    };
    // console.log('[App] Extracted Notification Data:', structured);
    return structured;
  }
}

//                     +---------------------------+
//                     |       User Interaction    |
//                     |  (Clicked / Touched App) |
//                     +------------+--------------+
//                                  |
//                 +----------------+----------------+
//                 |                                 |
//           +-----v-----+                     +-----v-----+
//           |  Foreground|                     | Background|
//           |  Tab Active|                     |   Tab    |
//           +-----+-----+                     +-----+-----+
//                 |                                 |
//       +---------+---------+               +-------+-------+
//       | Sound Plays        |               | Audio unlocked?|
//       | Immediately        |               +-------+-------+
//       +-------------------+                       |
//                                                 +--+--+
//                                                 |     |
//                                            +----v---+ +---v----+
//                                            | Yes    | |  No    |
//                                            | Sound  | | Blocked|
//                                            | Plays  | | Sound  |
//                                            +--------+ +--------+
// No tab open / user not logged in → Sound cannot play, only system notification appears.
// “Silent” AudioContext
// A silent AudioContext is an AudioContext that plays a tiny, empty buffer with no sound.
// Purpose: browsers now consider the user “interacted” with audio, so future audio can be played without being blocked, even in background tabs.
